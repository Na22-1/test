/**
 * 
 */
/**
 * Package um Wurfel und Wurfelbecher zu erstellen.
 * @author Natia Baindurashvili 310658   
 *
 */
package spiel.wuerfel;