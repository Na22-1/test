package spiel.wuerfel;

/**
 * 
 * In diese Klasse wird die Zufaelligkeits wert fuer Wuerfel werte generiert.
 * 
 * @author Natia Baindurashvili 310658   
 *
 */
public class Zufaellichkeit {

    /**
     * Zufaellichkeitswert von 1 bis 6 generieren. 
     * @return aktuelle zufalls Wert
     */
    protected static int zufallsWert() {
        return (int) (1 + Math.random() * (7 - 1));
    }
}
