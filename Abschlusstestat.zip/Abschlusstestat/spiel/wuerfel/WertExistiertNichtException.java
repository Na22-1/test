/**
 * 
 */
package spiel.wuerfel;

/**
 * Hier wird die Exceptions geworfen, wenn der einegegebene Wert nicht 
 * exisitiert.
 * @author Natia Baindurashvili 310658   
 *
 */
public class WertExistiertNichtException extends RuntimeException {

    /**
     * Automatisch generiert.
     */
    private static final long serialVersionUID = -3264504886952395970L;

}
