package spiel.wuerfel;

import java.util.InputMismatchException;
import java.util.Scanner;

import spiel.Spieler;

/**
 * Klasse um Wurfelbecher zu erstellen und zu spielen.
 * 
 * @author Natia Baindurashvili 310658
 *
 */
public class Wurfelbecher {

    /**
     * Scanner um Nutzer eingaben zu ermoeglichen.
     */
    private Scanner eingabe = new Scanner(System.in);
    /**
     * Wuerfel.
     */
    private Wuerfel[] wuerfel;

    /**
     * Konstruktoer um wuerfel zu erstellen.
     */
    public Wurfelbecher() {
        this.wuerfel = new Wuerfel[5];
        for (int i = 0; i < wuerfel.length; i++) {
            wuerfel[i] = new Wuerfel(Zufaellichkeit.zufallsWert());
        }
    }

    /**
     * der Würfelbecher geschütteltwird, werden alle Würfel darin gewürfelt
     * (bekommen also einen neuen, zufälligen aktuellen Wert).
     * @param spieler 
     */
    public void schutteln(Spieler spieler) {
        int zaehleDieRunde = 0;
        
        do {
            System.out.print("Würfel: ");
            for (int i = 0; i < wuerfel.length; i++) {
                System.out.print(wuerfel[i].getAktuellerWert() + " ");

                spieler.punkteNachJederRundeAufsummieren(
                        wuerfel[i].getAktuellerWert());
            }
            wertHalten();
            zaehleDieRunde++;
        } while (zaehleDieRunde < 3);
     
    }

    /**
     * Im Methode wird gefragt, werches Wert gehalten werden soll. Falls dieses
     * Wert nicht existiert wird User eintsprechend informiert und gefragt, dass
     * Wert erneut eingeben muss.
     */
    private void wertHalten() {
        System.out.println("\n\nWelcher Wert soll gehalten werden?");
        int wert = 0;
        boolean richtigeEingabe = false;
        do {
            try {

                wert = eingabePruefen();

                // richtigeEingabe = pruefeObEingegebeneWertExistiert(wert);
                richtigeEingabe = true;
            } catch (WertExistiertNichtException e) {
                System.out.println(
                        "Wert existiert nicht, bitte " + "erneut eingeben!");
            }
        } while (!richtigeEingabe);

        halte(wert);

    }

    /**
     * Im Methode wird der Wert gehalten, der User ausgewaehlt hat. Restliche
     * Wuerfeln werden wieder normall geworfen, mit Zufallswert von 1 bis 6.
     * 
     * @param wert der Wert der gehalten wurde
     */
    private void halte(int wert) {

        for (int i = 0; i < wuerfel.length; i++) {
            if (wuerfel[i].getAktuellerWert() == wert) {
                // werte halten
                wuerfel[i].setAktuellerWert(wert);
            } else {
                wuerfel[i].wuerfeln();
            }
        }
    }

    /**
     * Hier wird geprueft ob, eingegebene Wert von nutzer existert. Falls dieses
     * Wert nicht existiert wird User entsprechend informiert und false
     * zueruckgegeben.
     * 
     * @param wert aktuele wert
     * @return richtigeEingabe
     */
    private boolean pruefeObEingegebeneWertExistiert(int wert) {
        boolean richtigeEingabe = true;
        if (wert != wuerfel[0].getAktuellerWert()) {
            richtigeEingabe = false;
            throw new WertExistiertNichtException();
        } else if (wert != wuerfel[1].getAktuellerWert()) {
            richtigeEingabe = false;
            throw new WertExistiertNichtException();
        } else if (wert != wuerfel[2].getAktuellerWert()) {
            richtigeEingabe = false;
            throw new WertExistiertNichtException();
        } else if (wert != wuerfel[3].getAktuellerWert()) {
            richtigeEingabe = false;
            throw new WertExistiertNichtException();
        } else if (wert != wuerfel[4].getAktuellerWert()) {
            richtigeEingabe = false;
            throw new WertExistiertNichtException();
        }
        return richtigeEingabe;
    }

    /**
     * Jeder Int Eingabe pruefen. Bei falschen Eingaben Nutzer entsprechend
     * Informieren.
     * 
     * @return eingabe
     */
    private int eingabePruefen() {
        int zahlEingeben = 0;
        boolean richtigeEingabe = false;
        do {
            try {
                zahlEingeben = eingabe.nextInt();
                richtigeEingabe = true;
            } catch (InputMismatchException e) {
                System.out.println("Nicht richtige Eingabe. Erneut!");
            } finally {
                eingabe.nextLine();
            }
        } while (!richtigeEingabe);
        return zahlEingeben;
    }

}
