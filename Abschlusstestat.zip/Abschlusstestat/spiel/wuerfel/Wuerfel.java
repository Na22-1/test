package spiel.wuerfel;

/**
 * Klasse fuer Wuerfel zu erstellen.
 * @author Natia Baindurashvili 310658
 */
public class Wuerfel {

    
    /**
     * Aktueller Wert fuuer wuerfel.
     */
    private int aktuellerWert;
    
    /**
     * summe Alle Wurfels.
     */
    private int summe;
    /**
     * Konstruktoer.
     * @param aktuellerWert
     */
    public Wuerfel(int aktuellerWert) {
        this.aktuellerWert = aktuellerWert;
      
    }

    /**
     * Da wird zufalls wert fuer der wuerfel generiert.
     */
    public void wuerfeln() {
        int aktuellerWert = Zufaellichkeit.zufallsWert();
        setAktuellerWert(aktuellerWert);
    }
    
    /**
     * Getter fuer aktuellerWert.
     * @return aktuellerWert die geworfen wurde.
     */
    protected int getAktuellerWert() {
        return aktuellerWert;
    }
    
    /**
     * Setter fuer Wert die werte.
     * @param aktuellerWert
     */
    protected void setAktuellerWert(int aktuellerWert) {
        this.aktuellerWert = aktuellerWert;
        setSumme(aktuellerWert);
    }
    
    /**
     * Setter fuer die Wurfel summe.
     * @param aktuellerWert
     */
    private void setSumme(int aktuellerWert) {
        this.summe += aktuellerWert;
    }
    
    /**
     * Getter fuer sume.
     * @return summe
     */
    
    protected int getSumme() {
        return summe;
    }
}

