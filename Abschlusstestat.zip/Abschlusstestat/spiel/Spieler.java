/**
 * 
 */
package spiel;

/**
 * Die Klasse um 2 Spieler zu erzeugen.
 * 
 * @author Natia Baindurashvili 310658
 *
 */
public class Spieler {

    /**
     * Die Summe fuer gesamte punkte.
     */
    private int punkteSumme;
    /**
     * Es wird gezaehlt ob Spieler im Runde gewonnen hat.
     */
    private int zaehleObSpielerGewonnenHat;

    /**
     * Konstruktoer fuer Spieler.
     * 
     */
    public Spieler() {
     
    }

    /**
     * AM ende des Rundes wiird User Informiert wieviel Punkten der gesammelt
     * hat.
     * 
     * @param punkte
     */
    public void punkteNachJederRundeAufsummieren(int punkte) {
        this.punkteSumme += punkte;
       

    }
    
    /**
     * Getter fuer Punktre.
     * @return punkteSumme
     */
    public int getPunkteSumme() {
        return punkteSumme;
    }

    /**
     * Es wird nach weder runde, gezaehlt ob Spieler gewonnen hat.
     * 
     * @param winn
     * 
     */
    public void setZaehleObSpielerGewonnenHat(int winn) {

        this.zaehleObSpielerGewonnenHat += winn;
    }

    /**
     * Getter fuer gewinnungs zaehler.
     * 
     * @return zaehleObSpielerGewonnenHat
     */
    public int getZaehleObSpielerGewonnenHat() {
        
        return zaehleObSpielerGewonnenHat;
    }
}
