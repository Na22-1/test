package spiel;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import spiel.wuerfel.Wurfelbecher;

/***
 * Klasse um Spiel anzufangen und am Ende Winner Bestimmen.
 * @author Natia Baindurashvili 310658
 */
public class Spiel {

    /**
     * wurfelbecher.
     */
    private Wurfelbecher wurfelbecher;
    /**
     * Die Aktuelle Spieler.
     */
    private Spieler[] spieler;

    /**
     * Konstruktor um wurfelbecher und Spieler zu erstellen.
     */
    public Spiel() {
        this.wurfelbecher = new Wurfelbecher();
        this.spieler = new Spieler[2];
        this.spieler[0] = new Spieler();
        this.spieler[1] = new Spieler();
    }

    /**
     * In jeder Runde ist zuerst Spieler 1 und dann Spieler 2 dran.Es wird erste
     * reihe ohne das Wert gehalten gespielr, danach muss Wert gehalten werden.
     * Jeder Spieler spielt 3 runde. Am ende des rundes Werte aufssummieren und
     * Winner der Runde bestimmen. Wer 5 Runde gewonnen hat, der ist winner.
     */
    public void spielen() {
        int rundeZehllen = 1;
     
        do {
            System.out.println("\n    Runde " + rundeZehllen + "    \n");
            for (int i = 0; i < spieler.length; i++) {

                System.out.println("Spieler: " + (i + 1));
                wurfelbecher.schutteln(spieler[i]);
                
                if (spieler[0].getPunkteSumme() > spieler[1].getPunkteSumme()) {
                    spieler[i].setZaehleObSpielerGewonnenHat(1);
                } else {
                    spieler[i + 1].setZaehleObSpielerGewonnenHat(1);
                }
            }
            // Jede Runde zaehlen
            drueckeGewinnerFuerRunde();
            rundeZehllen++;
        } while (spieler[0].getZaehleObSpielerGewonnenHat() != 5
                && spieler[1].getZaehleObSpielerGewonnenHat() != 5);

        dureckeWinner();

    }

    /**
     * Im Methode wird gdrueckt welche Spieler gewonnen hat.
     */
    private void dureckeWinner() {
        if (spieler[0].getPunkteSumme() > spieler[1].getPunkteSumme()) {

            System.out.println("Spieler 1 hat gewonnen!");
        } else {
            System.out.println("Spieler 2 hat gewonnen!");
        }

    }

    /**
     * Main Methode.
     * 
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("Willkommen zum Würfelspiel!");
        Spiel spiel = new Spiel();
        spiel.spielen();

        spiel.textDateiErstellen();

    }

    /**
     * Nach jeder Rundewird gedrukti wer wie viele Punkten hat.
     */
    private void drueckeGewinnerFuerRunde() {

        System.out.println(
                "Spieler 1: " + spieler[0].getZaehleObSpielerGewonnenHat());
        System.out.println(
                "Spieler 2: " + spieler[0].getZaehleObSpielerGewonnenHat());

    }

    /**
     * fuer Klausurrelevante Textdatei Mit 
     * Personliche Informationen Erstellen.
     */
    private void textDateiErstellen() {
        FileWriter writer;
        File datei = new File("testat.txt");

        try {
            writer = new FileWriter(datei);
            writer.write("Vor- und Nachname: Natia Baindurashvili\n"
                    + "Matrikelnummer: 310658\n"
                    + "Studiengang: Wirtschaftsinformatik\n" + "Semester: 1\n"
                    + "Ich bin mit der Veröffentlichung meiner Note im Learnweb"
                    + " unter\n"
                    + "Angabe meiner Matrikelnummer einverstanden.");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
