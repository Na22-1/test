/**
 * 
 */
/**
 * 
 * Package um Spiel anzufangen und dazu benoetigte Werte zu generieren.
 * @author Natia Baindurashvili 310658   
 *
 */
package spiel;